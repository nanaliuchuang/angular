export class _listStudent{
    name: string;
    age:number;
    city: string;
    dob: Date;
    constructor(name:string, age: number, city: string,dob:Date){
    this.name = name;
    this.age = age;
    this.city = city;
    this.dob = dob;
    }
}
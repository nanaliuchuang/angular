import { Injectable } from '@angular/core';
import food from './food.json';
@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { }
  getFood(){
    return food;
  }
}

import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
import FoodJson from '../food.json'

interface Food{
  name: string,
  image: ImageBitmapSource,
  price: number,
  description: string
}
@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {
  food: Food[] = FoodJson;

  constructor(public foodService: FoodService) { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
import FoodJson from '../food.json'

interface Food{
  name: string,
  image: ImageBitmapSource,
  price: number,
  description: string
}
@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {
  food: Food[] = FoodJson;
  public listFood: Array<any> = [];
  public foodI : any= {};

  constructor(public foodService: FoodService) { 
    this.listFood = this.foodService.getFood();
  }

  ngOnInit(): void {
  }

  showFood(i:number){
    this.foodI = this.listFood[i];
  }
}

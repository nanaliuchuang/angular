import { Component, OnInit } from '@angular/core';
import { FoodService } from '../food.service';
import FoodJson from '../food.json'

@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {
  public listFood: Array<any> = [];
  public foodI : any= {};

  constructor(public foodService: FoodService) { 
    this.listFood = foodService.getFood();
  }

  ngOnInit(): void {
  }

  showFood(i:number){
    this.foodI = this.listFood[i];
  }
}

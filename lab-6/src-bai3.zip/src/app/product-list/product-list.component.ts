import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { IProducts } from '../product';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  products: any = {};
  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.show();
  }

  show(){
    return this.productService.getAllProduct().subscribe((data: {})=>{
      this.products = data;
    })
  }
  addTocart(product:any){
    this.productService.event.emit(product);
  }
}


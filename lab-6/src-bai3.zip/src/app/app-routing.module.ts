import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartListComponent } from './cart-list/cart-list.component';
import { ProductListComponent } from './product-list/product-list.component';

const routes: Routes = [
  {path: '', pathMatch: 'full',redirectTo: 'card-list'},
  {path: 'card-list', component: CartListComponent},
  {path: 'product-list',component: ProductListComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export interface IProducts {
    id: number;
    item: string;
    price: number;
    content: string;
    quanity: number;
  }
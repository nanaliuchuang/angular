import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  @Output() event = new EventEmitter();
  constructor(private http:HttpClient) { }
  getAllProduct(){
    return this.http.get(`https://629a06d67b866a90ec47e89f.mockapi.io/shoping-cart`);
  }
  getProductById(id:number): Observable<any>{
    return this.http.get(`https://629a06d67b866a90ec47e89f.mockapi.io/shoping-cart/${id}`);
  }

}

import { Component, OnInit } from '@angular/core';
import { IProducts } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.css']
})
export class CartListComponent implements OnInit {

  products:any = [];
  cartProduct: IProducts[]=[];
  totalQaunity:number = 0;
  tax: number = 2.04;
  price:number=0;
  totalPrice:number=0;
  constructor(private productService: ProductService) { }

  show(){
    return this.productService.getAllProduct().subscribe((data: {})=>{
      this.products = data;
    })
  }
  ngOnInit(): void {
    this.show();
    this.productService.event.subscribe(product => {
      let index = -1;
      index = this.cartProduct.findIndex(
        p => p.id === product.id
      );
      if(index != -1){
        this.cartProduct[index].quanity +=1;
      }
      else if(index === -1){
        this.cartProduct.push(product);
      }
      this.sum();
    })
  }
  deleteProduct(id:any){
    let index = this.cartProduct.findIndex(item => item.id === id);
    this.cartProduct.splice(index,1);
    this.sum();
  }
  sum(): void{
    this.totalPrice = 0;
    this.price = 0;
    this.totalQaunity = 0;
    if(this.cartProduct){
      this.cartProduct.map(product =>{
        this.price += product.price;
        this.totalQaunity += product.quanity;
        this.totalPrice += (product.price * product.quanity) + this.tax;
      })
    }
  }

}

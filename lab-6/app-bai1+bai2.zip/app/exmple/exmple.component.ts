import { Component, OnInit } from '@angular/core';
import { observable, Observable } from 'rxjs';

@Component({
  selector: 'app-exmple',
  templateUrl: './exmple.component.html',
  styleUrls: ['./exmple.component.scss']
})
export class ExmpleComponent implements OnInit {

  str: string="";
  s:number = 0;

  constructor() {
   }

  ngOnInit(): void {
    const ob = new Observable((oberseble) => {
      const id = setTimeout(()=>{
        oberseble.next("Hello Rxjs");
        oberseble.next("Hello A");
        oberseble.complete();
      },1000);
    });

    const subcription = ob.subscribe({
      next(value){
        console.log(value);
      },
      error:(error)=>{
        console.log(error);
      },
      complete:()=>{
        console.log('Done');
      }
    });
    setTimeout(()=>{
      subcription.unsubscribe();
    },5000);
  }

}

import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrls: ['./user-create.component.scss']
})
export class UserCreateComponent implements OnInit {

  @Input() UserDetails = {name: '', email: '', phone: ''};
  constructor(private crucdService: CrudService, private router: Router) { }

  ngOnInit(): void {
  }
  addUser(dataUser:any){
    this.crucdService.create(this.UserDetails).subscribe((data: {}) => {
      this.router.navigate(['/user-list']);
    });
  }

}

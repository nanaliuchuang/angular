import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Post } from './post.model';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  constructor(private http: HttpClient) { }
  getPostt():Observable<Post[]>{
    return this.http.get<Post[]>('htttps://jsonplaceholder.typicode.com/posts');
  }
  addPost(post: Post):Observable<Post>{
    return this.http.post<Post>('htttps://jsonplaceholder.typicode.com/posts',post);
  }
  deletePost(id:Number): Observable<any>{
    return this.http.delete(`htttps://jsonplaceholder.typicode.com/posts/${id}`);
  }
  updatePost(id: Number, post: Partial<Post>): Observable<Post>{
    return this.http.put<Post>(`htttps://jsonplaceholder.typicode.com/posts/${id}`,post);
  }
}

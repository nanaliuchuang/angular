import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
  registerForm = new FormGroup({
    userName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    lastName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(10),
    ]),
    firstName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(10),
    ]),
    address: new FormGroup({
      city: new FormControl('', [
        Validators.required]),
      state: new FormControl('', [
        Validators.required]),
      zip: new FormControl('', [
        Validators.required]),
      check: new FormControl('', [
        Validators.required])
    })
  });

  user:any='';
  name:any='';
  address:any='';
  zipp:any='';
  get userName(){
    return this.registerForm.get('userName');
  }

  public get lastName(){
    return this.registerForm.get('lastName');
  }

  public get firstName(){
    return this.registerForm.get('firstName');
  }
  
  public get state(){
    return this.registerForm.get("address")?.get('state');
  }

  public get city(){
    return this.registerForm.get("address")?.get('city');
  }

  public get zip(){
    return this.registerForm.get("address")?.get('zip');
  }

  public get check(){
    return this.registerForm.get("address")?.get('check');
  }


  onSave(){
    console.log(this.registerForm.value);
    this.user= 'Uername : ' + this.registerForm.get('userName')?.value;
    this.name = 'Full name : ' + this.registerForm.get('lastName')?.value+' '+this.registerForm.get('firstName')?.value;
    this.address = 'Address : ' + this.registerForm.get('address')?.get('state')?.value+' , '+this.registerForm.get('address')?.get('city')?.value;
    this.zipp = 'Zip : ' +this.registerForm.get('address')?.get('zip')?.value;
  }
}

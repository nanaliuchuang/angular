import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { __values } from 'tslib';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.scss'],
})
export class RegisterFormComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
  registerForm = new FormGroup({
    userName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    lastName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    firstName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ])
  });

  user:any='';
  name:any='';
  public get userName(){
    return this.registerForm.get('userName');
  }

  public get lastName(){
    return this.registerForm.get('lastName');
  }

  public get firstName(){
    return this.registerForm.get('firstName');
  }

  public get password(){
    return this.registerForm.get('password');
  }
  
  onSave(){
    console.log(this.registerForm.value);
    this.user= 'Uername : ' + this.registerForm.get('userName')?.value;
    this.name = 'Full name : ' + this.registerForm.get('lastName')?.value+' '+this.registerForm.get('firstName')?.value;
  }
}

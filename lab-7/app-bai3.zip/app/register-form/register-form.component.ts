import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css'],
})
export class RegisterFormComponent implements OnInit {
  constructor(private registerService: RegisterService) {}

  ngOnInit(): void {}
  registerForm = new FormGroup({
    userName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    lastName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    firstName: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
  });

  user: any = '';
  name: any = '';
  pass: any = '';

  public userArr: Array<any> = [];
  public user_name: any = '';
  public first_name: any = '';
  public last_name: any = '';
  public user_password: any = '';

  public get userName() {
    return this.registerForm.get('userName');
  }

  public get lastName() {
    return this.registerForm.get('lastName');
  }

  public get firstName() {
    return this.registerForm.get('firstName');
  }

  public get password() {
    return this.registerForm.get('password');
  }

  onSave() {
    console.log(this.registerForm.value);
    this.user = 'Username : ' + this.registerForm.get('userName');
    this.name =
      'Full name : ' +
      this.registerForm.get('lastName') +
      ' ' +
      this.registerForm.get('lastName');
    this.pass = 'Password : ' + this.registerForm.get('password');
  }

  addUser() {
    this.user_name = this.registerForm.value.userName;
    this.last_name = this.registerForm.value.lastName;
    this.first_name = this.registerForm.value.firstName;
    this.user_password = this.registerForm.value.password;
    let User = {
      'id': this.userArr.length + 2,
      'username': this.user_name,
      'lastname': this.last_name,
      'firstname': this.first_name,
      'password': this.user_password,
    }

    this.userArr.push(User);
  }
}

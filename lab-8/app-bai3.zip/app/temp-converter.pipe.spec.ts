import { TempConverterPipe } from './temp-converter.pipe';

describe('TempConverterPipe', () => {
  it('create an instance', () => {
    const pipe = new TempConverterPipe();
    expect(pipe).toBeTruthy();
  });
});

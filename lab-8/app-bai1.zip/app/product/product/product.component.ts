import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  products:Array<any> = [
    {
      name: 'Iphone xs max',
      price: 20000000,
      qty: 20
    },
    {
      name: 'Macbook pro 2000',
      price: 45000000,
      qty: 10
    },
    {
      name: 'IMac 2020',
      price: 30000000,
      qty: 5
    }
  ];
  constructor() { }

  ngOnInit(): void {
  }

}

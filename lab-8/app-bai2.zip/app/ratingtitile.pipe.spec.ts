import { RatingtitilePipe } from './ratingtitile.pipe';

describe('RatingtitilePipe', () => {
  it('create an instance', () => {
    const pipe = new RatingtitilePipe();
    expect(pipe).toBeTruthy();
  });
});

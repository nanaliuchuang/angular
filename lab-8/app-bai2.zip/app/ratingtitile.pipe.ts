import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ratingtitile'
})
export class RatingtitilePipe implements PipeTransform {

  transform(value: number, classify: string): any {
    if(value && !isNaN(value)){
      if(value < 5){
        const result = 'Chua Dat';
        return result;
      }
      if(value <=7 && value >= 5){
        const result = 'Dat';
        return result;
      }
      if(value > 7){
        const result = 'Xuat Sac';
        return result;
      }
    }
  }

}

export class Server{
    name: string;
    content: string;
    type: string;
    public constructor(){
        this.name = "";
        this.content = "";
        this.type = "";
    }
}
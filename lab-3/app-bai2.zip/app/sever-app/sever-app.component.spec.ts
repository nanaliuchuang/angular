import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeverAppComponent } from './sever-app.component';

describe('SeverAppComponent', () => {
  let component: SeverAppComponent;
  let fixture: ComponentFixture<SeverAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeverAppComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SeverAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

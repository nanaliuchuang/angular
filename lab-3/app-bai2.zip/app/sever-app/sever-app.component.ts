import { Component, OnInit } from '@angular/core';
import { Server } from './app-server';

@Component({
  selector: 'app-sever-app',
  templateUrl: './sever-app.component.html',
  styleUrls: ['./sever-app.component.css'],
})
export class SeverAppComponent implements OnInit {
  days:any= 11;

  constructor() {}
  onReset(){
    this.days = '';
  }
  ngOnInit(): void {}
}

import { DropdownDirective } from './dropdown.directive';

describe('DropdownDirective', () => {
  it('should create an instance', () => {
    const directive = new DropdownDirective();
    expect(directive).toBeTruthy();
  });
});

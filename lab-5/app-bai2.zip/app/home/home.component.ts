import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public post: any = {};
  public posts : Array<any>;
  constructor( private postService: PostService, private route: ActivatedRoute) {
    this.posts = this.postService.getAllPost();
   }

   ngOnInit() {
    this.post = this.route.snapshot.paramMap.get('id');
  }


}

export const posts: Array<any> = [
  {
    id: 1,
    title:
      'Tò mò chàng DJ Người ấy là ai khiến người đẹp Hoa hậu Hoàn vũ có quyết định bất ngờ',
    description:
      'Nam chính Người Ấy Là Ai kết đôi với Như Mỹ - cựu thí sinh Hoa Hậu Hoàn Vũ Việt Nam 2022 được cư dân mạng lùng "in tư" sau khi xuất hiên trên sóng truyền hình.',
  },
  {
    id: 2,
    title:
      'Sai sót xét nghiệm nồng độ cồn nữ sinh tử nạn: Cần làm rõ có chủ đích, chủ mưu hay không?',
    description:
      'Luật sư cho rằng, sai sót trong việc xác định nồng độ cồn đối với vụ việc tai nạn giao thông nghiêm trọng là không thể chấp nhận được. Đặc biệt là xác định nồng độ cồn đối với nạn nhân đã chết, do đó, cơ quan chức năng cần xác minh, làm rõ sai sót này là có chủ đích hay không?',
  },
  {
    id: 3,
    title: 'Cách gội đầu với vitamin B5 giúp giảm rụng tóc hiệu quả',
    description:
      'Gội đầu với vitamin B5 là một trong những liệu pháp tự nhiên giúp giảm rụng tóc và kích thích tóc mọc hiệu quả. Dưới đây là 3 cách gội đầu với vitamin B5 đơn giản có thể thực hiện ngay tại nhà để chăm sóc tóc khỏe mạnh.',
  },
  {
    id: 4,
    title: 'Huyền Lizzie tung clip diện bikini "bốc lửa" khó rời mắt',
    description:
      'Kết thúc hành trình Thương Ngày Nắng Về, Huyền Lizzie "đốt mắt" cư dân mạng khi diện bikini nóng bỏng.',
  },
  {
    id: 5,
    title:
      'Phá vỡ những rào cản xưa cũ, đây là cách chiếc TV kỳ lạ này chinh phục giới trẻ',
    description:
      'Gặp được chàng trai đúng gu của mình, nhưng "hot girl ảnh thẻ" Lan Hương vẫn bật khóc và đưa ra quyết định từ chối tình ...',
  },
];

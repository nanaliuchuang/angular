import { Injectable } from '@angular/core';
import { products } from './mock.products';
@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  public _productList: Array<any> = [];
  constructor() { }
  getProduct(){
    return this._productList = products;
  }
}

export class Product{
    public id: any = '';
    public name: string = '';
    public description: string = '';
    public category: string = '';
    public order: string = '';
    
    constructor(){
        this.id = '';
        this.name = '';
        this.description = '';
        this.category = '';
        this.order = '';
    }
}
export const products: Array<any> = [
{
    id: 1,
    name: 'product 1',
    description: 'description 1',
    category: 'category 1',
    order: 'order 1',
},
{
    id: 2,
    name: 'product 2',
    description: 'description 2',
    category: 'category 2',
    order: 'order 2',
},{
    id: 3,
    name: 'product 3',
    description: 'description 3',
    category: 'category 3',
    order: 'order 3',
},{
    id: 4,
    name: 'product 4',
    description: 'description 4',
    category: 'category 4',
    order: 'order 4',
},{
    id: 5,
    name: 'product 5',
    description: 'description 5',
    category: 'category 5',
    order: 'order 5',
},
]
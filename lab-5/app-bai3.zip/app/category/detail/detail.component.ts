import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/category.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailsComponent implements OnInit {

  public detail: any = {};
  constructor( private category: CategoryService,private route: ActivatedRoute) { }

  ngOnInit(): void {
    const routeParams = this.route.snapshot.paramMap;
    const postId = Number(routeParams.get('id'));
    this.detail = this.category.getCategory().find(category => category.id === postId);
  }

}

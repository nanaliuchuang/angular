import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from '../category.service';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  public product: any = {};
  public productList: Array<any>;
  constructor(private prudtsService: CategoryService,private route: ActivatedRoute) { 
    this.productList = this.prudtsService.getCategory();
  }

  ngOnInit(): void {
    this.product = this.route.snapshot.paramMap.get('id');
  }

}

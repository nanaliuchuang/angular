import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/category.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  public id = '';
  public category = '';
  public categoryList: Array<any> = [];
  public newcategory = {};
  constructor( private categoryService: CategoryService) {
    this.categoryList = this.categoryService.getCategory();

   }

  ngOnInit(): void {
  }
  public onSubmit(){
    this.newcategory = {
      id: this.id,
      category: this.category,
    }
    this.categoryList.push(this.newcategory);
  }

}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CategoryComponent } from './category/category.component';
import { NewComponent } from './new/new.component';
import { OrderComponent } from './order/order.component';
import { ProductsComponent } from './products/products.component';
import { DetailComponent } from './detail/detail.component';
import { Product } from './product';
import { DetailsComponent } from './category/detail/detail.component';
import { AddComponent } from './category/add/add.component';
@NgModule({
  declarations: [
    AppComponent,
    CategoryComponent,
    NewComponent,
    OrderComponent,
    ProductsComponent,
    DetailComponent,
    DetailsComponent,
    AddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [Product],
  bootstrap: [AppComponent]
})
export class AppModule { }

export const category: Array<any> = [
    {
        id: 1,
        category: 'Smart phone'
    },
    {
        id: 2,
        category: 'Tv'
    },{
        id: 3,
        category: 'Smart Blutooth'
    },{
        id: 4,
        category: 'Beauty & Fashion'
    },{
        id: 5,
        category: 'Make up'
    },
    ]
import { Injectable } from '@angular/core';
import { category } from './mock.category';
@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  public _productList: Array<any> = [];
  constructor() { }
  getCategory(){
    return this._productList = category;
  }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CategoryComponent } from './category/category.component';
import { DetailComponent } from './detail/detail.component';
import { NewComponent } from './new/new.component';
import { OrderComponent } from './order/order.component';
import { ProductsComponent } from './products/products.component';
import { DetailsComponent } from './category/detail/detail.component';
import { AddComponent } from './category/add/add.component';

const routes: Routes = [
  {
    path: 'products',
    component: ProductsComponent,
    children: [{ path: 'new', component: NewComponent }],
  },
  { path: 'products/:detail/:id', component: DetailComponent },
  { path: 'category/:details/:id', component: DetailsComponent},
  { path: 'category', component: CategoryComponent,
  children: [{ path: 'add', component: AddComponent }],},
  { path: 'order', component: OrderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}

import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  public product: any = {};
  public productList: Array<any>;
  constructor(private prudtsService: ProductsService,private route: ActivatedRoute, private router: Router) { 
    this.productList = this.prudtsService.getProduct();
  }

  ngOnInit(): void {
    this.product = this.route.snapshot.paramMap.get('id');
  }

}

import { Injectable } from '@angular/core';
import music from '../db.json'
@Injectable({
  providedIn: 'root'
})
export class MusicService {

  constructor( ) { }
  getMusic(){
    return music;
  }

}

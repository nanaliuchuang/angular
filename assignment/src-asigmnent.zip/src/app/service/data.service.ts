import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Music } from '../playsist/music.model';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  data: Subject<any>;
  constructor() {
    this.data = new Subject();
   }
  add(mdata: Music){
    this.data.next(mdata);
  }
  get(){
    return this.data;
  }
}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayerComponent } from './mytool/player/player.component';
import { MyPlaysistComponent } from './mytool/my-playsist/my-playsist.component';
import { HomeComponent } from './component/home/home.component';
import { CategoryComponent } from './component/category/category.component';
import { AlbumComponent } from './component/album/album.component';
import { FormsModule } from '@angular/forms';
import { DetailComponent } from './component/detail/detail.component';
import { SearchPipe } from './search.pipe';
import { MenuComponent } from './component/menu/menu.component';

@NgModule({
  declarations: [
    AppComponent,
    PlayerComponent,
    MyPlaysistComponent,
    HomeComponent,
    CategoryComponent,
    AlbumComponent,
    DetailComponent,
    SearchPipe,
    MenuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

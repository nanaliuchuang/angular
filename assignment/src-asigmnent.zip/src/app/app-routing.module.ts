import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AlbumComponent } from './component/album/album.component';
import { CategoryComponent } from './component/category/category.component';
import { DetailComponent } from './component/detail/detail.component';
import { HomeComponent } from './component/home/home.component';

const routes: Routes = [
  {path:'',pathMatch: 'full',redirectTo:'home'},
  {path: 'home',component:HomeComponent},
  {path: 'category',component: CategoryComponent},
  {path: 'album',component: AlbumComponent},
  {path: 'detail/:id',component: DetailComponent},
  {path: 'album/:id',component:AlbumComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

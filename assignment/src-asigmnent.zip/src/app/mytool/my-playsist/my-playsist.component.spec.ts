import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyPlaysistComponent } from './my-playsist.component';

describe('MyPlaysistComponent', () => {
  let component: MyPlaysistComponent;
  let fixture: ComponentFixture<MyPlaysistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyPlaysistComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyPlaysistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

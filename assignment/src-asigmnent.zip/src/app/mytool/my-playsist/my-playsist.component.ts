import { Component, OnInit } from '@angular/core';
import { Music } from 'src/app/playsist/music.model';
import { MusicsQuery } from 'src/app/playsist/music.query';
import { DataService } from 'src/app/service/data.service';

@Component({
  selector: 'app-my-playsist',
  templateUrl: './my-playsist.component.html',
  styleUrls: ['./my-playsist.component.css']
})
export class MyPlaysistComponent implements OnInit {

  constructor(private _data: DataService,private musicQuerry:MusicsQuery) { }

  musicDatas: Music[] = [];

  ngOnInit(): void {
    const datas = this.musicQuerry.selectAll();
    datas.subscribe((res: Music[]) => {
      this.musicDatas = res;
      console.log(res);
    })
  }

  sendData(music:Music){
    this._data.add(music);

  }
  
}

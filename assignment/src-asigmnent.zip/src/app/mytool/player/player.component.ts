import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { Music } from 'src/app/playsist/music.model';
import { DataService } from 'src/app/service/data.service';
@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})
export class PlayerComponent implements OnInit {
  duration: any = 100;
  currentTime = 0;
  isPlay: boolean = false;
  timeupdate = 0;

  files: Array<any> = [];


  volume = 0.5;
  readCurentTime = '00:00';
  readDuration: any = '00:00';
  mydata:any = {
    img: '',
    label: '',
    author: '',
  };

  audio: any;
  audioEvent = [
    "ended",
    "error",
    "play",
    "playing",
    "pause",
    "timeupdate",
    "canplay",
    "loadedmetadata",
    "loadstart"
  ];

  constructor(private _data: DataService) {
    this.audio = new Audio();
    this.audio.load();
  }

  ngOnInit(): void {
    this._data.get().subscribe((ob) => {
      console.log(ob);

      this.mydata = ob;
      this.playStream(ob).subscribe((ev : any) => {
        console.log("event", ev.type);
        
      });

    });
  }

  formartTime(time:any, format = "mm:ss"){
    const momentTime = time * 1000;
    console.log(momentTime);
    return moment.utc(momentTime).format(format);

  }
  setSeek(value: any) {
    this.audio.currentTime = value;
    console.log(value);
  }

  setVolume(value: any) {
    const vol_icon = document.getElementById('vol_icon');
    this.audio.volume = value;
    console.log(value);
    if (this.audio.volume == 0) {
      vol_icon?.classList.add('fa-volume-xmark');
      vol_icon?.classList.remove('fa-volume-low');
      vol_icon?.classList.remove('fa-volume-high');
    }
    if (this.audio.volume > 0) {
      vol_icon?.classList.remove('fa-volume-xmark');
      vol_icon?.classList.add('fa-volume-low');
      vol_icon?.classList.remove('fa-volume-high');
    }
    if (this.audio.volume > 0.5) {
      vol_icon?.classList.remove('fa-volume-xmark');
      vol_icon?.classList.remove('fa-volume-low');
      vol_icon?.classList.add('fa-volume-high');
    }
  }
  isStart() {
    return true;
  }
  previous() {}

  isplay() {
    return true;
  }
  next() {}

  playStream(ob: Music) {

    return new Observable(observer => {
      this.audio.src = ob.url;
      this.audio.load();

      const handle = (event: Event)=>{
        console.log(event.type, this.audio.currentTime);
        this.readCurentTime = this.formartTime(this.currentTime);
        this.currentTime = this.audio.currentTime;
        this.duration = this.audio.duration;
        this.readDuration = this.formartTime(this.duration);
        observer.next(event);
      };

      this.addEvents(this.audio, handle);

    });
  }

  addEvents(audioObj:any, handler:any){
    this.audioEvent.forEach(event => {
      audioObj.addEventListener(event, handler)
    });
  }
  play() {
    const wave = document.getElementById('wave');
    wave?.classList.add('active1');
    this.audio.play();
    this.isPlay = true;
  }
  pause() {
    const wave = document.getElementById('wave');
    wave?.classList.remove('active1');
    this.audio.pause();
    this.isPlay = false;
  }
  shuffe() {
    let shuffle = document.getElementsByClassName('shuffle')[0];
    let a = shuffle.innerHTML;
    switch (a) {
      case 'next':
        shuffle.classList.add('fa-repeat');
        shuffle.classList.remove('fa-music');
        shuffle.classList.remove('fa-shuffle');
        shuffle.innerHTML = 'repeat';
        break;
      case 'repeat':
        shuffle.classList.remove('fa-repeat');
        shuffle.classList.remove('fa-music');
        shuffle.classList.add('fa-shuffle');
        shuffle.innerHTML = 'random';
        break;
      case 'random':
        shuffle.classList.remove('fa-repeat');
        shuffle.classList.add('fa-music');
        shuffle.classList.remove('fa-shuffle');
        shuffle.innerHTML = 'random';
        break;
    }
  }
}


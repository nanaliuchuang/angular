declare module"*.json"{
const music:any;
export default music;
}

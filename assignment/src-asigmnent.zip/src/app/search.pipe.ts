import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(listMusic: any, filterTerm: any): any {
    if (filterTerm === undefined) {
      console.log(listMusic);
      return listMusic;
    } else {
      return listMusic.filter(function (x: any) {
        console.log(x);
        return x.label.toLowerCase().includes(filterTerm.toLowerCase());
      });
    }
  }
}

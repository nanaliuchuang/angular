import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MusicService } from 'src/app/service/music.service';
import { DataService } from 'src/app/service/data.service';
import { Music } from 'src/app/playsist/music.model';
import { MusicStore } from 'src/app/playsist/musics.store';
import { createMusic } from 'src/app/playsist/music.model';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

   
  public listMusic:Array<any> = [];
  public detail: any = {};
  public music: any = {};
  filterTerm: string = '';

  constructor(private musics: MusicService, private route: ActivatedRoute,private _data: DataService,private musicStor: MusicStore) { 

    this.listMusic = this.musics.getMusic();
  }
  ngOnInit(): void {
    this.music = this.route.snapshot.paramMap.get('id');
    const routeParams = this.route.snapshot.paramMap;
    const musicId = Number(routeParams.get('id'));
    this.detail = this.musics.getMusic().find((music: { id: number; }) => music.id === musicId)
  }
  sendDatas(music:Music){
    this._data.add(music);

  }
  sendData(data:any){
    console.log(data);
    this.musicStor.add(createMusic(data));
  }
  search(value: any) {
    const input = document.getElementsByTagName('input')[0];
    const seach_results = document.getElementsByClassName('seach_results')[0];
    let input_value = input.value.toUpperCase();
    let items = seach_results.getElementsByTagName('a');
    for (let index = 0; index < items.length; index++) {
      let as = items[index].getElementsByClassName('content')[0];
      let text_value = as.textContent || as.innerHTML;
      if (text_value.toUpperCase().indexOf(input_value) > -1) {
        items[index].style.display = 'flex';
      } else {
        items[index].style.display = 'none';
      }
      if (text_value.toUpperCase().indexOf(input_value) == 0) {
        items[index].style.display = 'none';
      }
    }
  }
}

import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { createMusic } from 'src/app/playsist/music.model';
import { MusicStore } from 'src/app/playsist/musics.store';
import { MusicService } from 'src/app/service/music.service';

@Component({
  selector: 'app-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.css']
})
export class AlbumComponent implements OnInit {

  songsData: Observable<any>;

  constructor( private music: MusicService,private musicStor: MusicStore ) { 
    this.songsData = this.music.getMusic();
    this.listMusic = this.music.getMusic();
  }

  filterTerm: string = '';
  public listMusic: Array<any> = [];

  ngOnInit(): void {
  }

  sendData(data:any){
    console.log(data);
    this.musicStor.add(createMusic(data));
  }
  search(value: any) {
    const input = document.getElementsByTagName('input')[0];
    const seach_results = document.getElementsByClassName('seach_results')[0];
    let input_value = input.value.toUpperCase();
    let items = seach_results.getElementsByTagName('a');
    for (let index = 0; index < items.length; index++) {
      let as = items[index].getElementsByClassName('content')[0];
      let text_value = as.textContent || as.innerHTML;
      if (text_value.toUpperCase().indexOf(input_value) > -1) {
        items[index].style.display = 'flex';
      } else {
        items[index].style.display = 'none';
      }
      if (text_value.toUpperCase().indexOf(input_value) == 0) {
        items[index].style.display = 'none';
      }
    }
  }
  showLeft() {
    const pop_song = document.getElementsByClassName('music')[0];
    pop_song.scrollLeft -= 300;
  }
  showRight() {
    const pop_song = document.getElementsByClassName('music')[0];
    pop_song.scrollLeft += 300;
  }
  artLeft() {
    const item = document.getElementsByClassName('item_artist')[0];
    item.scrollLeft -= 300;
  }
  artRight() {
    const item = document.getElementsByClassName('item_artist')[0];
    item.scrollLeft += 300;
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { createMusic, Music } from 'src/app/playsist/music.model';
import { MusicStore } from 'src/app/playsist/musics.store';
import { DataService } from 'src/app/service/data.service';
import { MusicService } from 'src/app/service/music.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  public blackpink: any = [];

  songsData: Observable<any>;

  constructor( private musics: MusicService,private musicStor: MusicStore,private actRoute: ActivatedRoute ,private _data: DataService) { 
    this.songsData = this.musics.getMusic();
    this.listMusic = this.musics.getMusic();
    this.blackpink = this.musics.getMusic().filter((music: {author: any})=> music.author === 'Blackpink');

  }

  sendDatas(music:Music){
    this._data.add(music);
  }


  public listMusic: Array<any> = [];
  public music: any = {};
  filterTerm: string = '';
  ngOnInit(): void {
    this.music = this.actRoute.snapshot.paramMap.get('id');
  }
  search(value: any) {
    const input = document.getElementsByTagName('input')[0];
    const seach_results = document.getElementsByClassName('seach_results')[0];
    let input_value = input.value.toUpperCase();
    let items = seach_results.getElementsByTagName('a');
    for (let index = 0; index < items.length; index++) {
      let as = items[index].getElementsByClassName('content')[0];
      let text_value = as.textContent || as.innerHTML;
      if (text_value.toUpperCase().indexOf(input_value) > -1) {
        items[index].style.display = 'flex';
      } else {
        items[index].style.display = 'none';
      }
      if (text_value.toUpperCase().indexOf(input_value) == 0) {
        items[index].style.display = 'none';
      }
    }
  }
  playAudio(){
    let audio = new Audio();
    audio.src = "assets/audio/blackpink.mp3";
    audio.load();
    audio.play();
  }
  sendData(data:any){
    console.log(data);
    this.musicStor.add(createMusic(data));
  }
  showLeft() {
    const pop_song = document.getElementsByClassName('music')[0];
    pop_song.scrollLeft -= 300;
  }
  showRight() {
    const pop_song = document.getElementsByClassName('music')[0];
    pop_song.scrollLeft += 300;
  }
  artLeft() {
    const item = document.getElementsByClassName('item_artist')[0];
    item.scrollLeft -= 300;
  }
  artRight() {
    const item = document.getElementsByClassName('item_artist')[0];
    item.scrollLeft += 300;
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'assingment-music';
  menu(){
    const menu_side = document.getElementsByClassName('menu_side')[0];
    menu_side.classList.add('active');
  }
  song(){
    const menu_side = document.getElementsByClassName('menu_side')[0];
    menu_side.classList.remove('active');

  }
}

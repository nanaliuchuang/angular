export interface Music{
    id: number | string;
    label: string;
    author: string;
    url: string;
    img: string;
    category:string,
    artist: string,
}
export function createMusic(params: Partial<Music>){
    return{
        id: params.id,
        label: params.label,
        author: params.author,
        url: params.url,
        img: params.img
    } as Music;
}
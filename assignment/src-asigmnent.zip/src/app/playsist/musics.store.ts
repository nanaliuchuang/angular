import { Injectable } from "@angular/core";
import { StoreConfig, EntityState, EntityStore } from "@datorama/akita";
import { Music } from "./music.model";

export interface MusicState extends EntityState<Music>{}

@Injectable({ providedIn: 'root'})
@StoreConfig({ name: 'musics'})
export class MusicStore extends EntityStore<MusicState>{
    
    constructor(){
        super();
    }
}

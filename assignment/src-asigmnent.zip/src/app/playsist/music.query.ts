import { Injectable } from "@angular/core";
import { QueryEntity } from "@datorama/akita";
import { MusicStore,MusicState } from "./musics.store";

@Injectable({ providedIn: 'root'})
export class MusicsQuery extends QueryEntity<MusicState>{

    constructor(protected override store: MusicStore){
        super(store);
    }
}
import { Component, OnInit } from '@angular/core';
import { Server } from './app-server';

@Component({
  selector: 'app-sever-app',
  templateUrl: './sever-app.component.html',
  styleUrls: ['./sever-app.component.css'],
})
export class SeverAppComponent implements OnInit {
  server: Server[] = [
    { name: 'Liz', content: 'Unknow', type: 'server' },
    { name: 'Nana', content: 'Unknow', type: 'serverBlue' },
  ];
  themServer(name: string, content: string) {
    let s = new Server();
    s.content = content;
    s.name = name;
    s.type = 'server';
    this.server.push(s);
  }
  themServerBlue(name: string, content: string) {
    let s = new Server();
    s.content = content;
    s.name = name;
    s.type = 'serverBlue';
    this.server.push(s);
  }
  constructor() {}

  ngOnInit(): void {}
}

import { Component, OnInit,Input,Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-app-child',
  templateUrl: './app-child.component.html',
  styleUrls: ['./app-child.component.css']
})
export class AppChildComponent implements OnInit {
@Input() item:string='';
@Input() server:string='';
@Output() newServerEvent = new EventEmitter<string>();
themServer(value:string,value2:string,type:string="server"){
  this.newServerEvent.emit(value)
  this.newServerEvent.emit(value2);
  this.newServerEvent.emit(type);
}
themServerBlue(value:string,value2:string,type:string="serverBlue"){
  this.newServerEvent.emit(value)
  this.newServerEvent.emit(value2);
  this.newServerEvent.emit(type);
}
  constructor() { }

  ngOnInit(): void {
  }

}

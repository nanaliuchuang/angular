import { Component } from '@angular/core';
import { Server } from './app-server';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'excercise-3';
  a = 'Execrcise 3';
  servers: Server[]=[];
addServer(newServerEvent:any){
  this.servers.push(newServerEvent);
}
}
